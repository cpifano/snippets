any role
--------

* :cpp:any:`Sphinx`
* ref function without parens :cpp:any:`hello`.
* ref function with parens :cpp:any:`hello()`.
* :cpp:any:`Sphinx::version`
* :cpp:any:`version`
* :cpp:any:`List`
* :cpp:any:`MyEnum`
