roles
-----

* :cpp:class:`Sphinx`
* ref function without parens :cpp:func:`hello`.
* ref function with parens :cpp:func:`hello()`.
* :cpp:member:`Sphinx::version`
* :cpp:var:`version`
* :cpp:type:`List`
* :cpp:enum:`MyEnum`
