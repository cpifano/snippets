graphviz
========

.. digraph:: foo
   :caption: caption of graph

   bar -> baz
