===
Foo
===

.. figure:: rimg.png

   should be Fig.1.1

.. csv-table:: should be Table 1.1
   :header-rows: 0

   hello,world

.. code-block:: python
   :caption: should be List 1.1

   print('hello world')

Foo A
=====

.. figure:: rimg.png

   should be Fig.1.2

.. figure:: rimg.png

   should be Fig.1.3

.. csv-table:: should be Table 1.2
   :header-rows: 0

   hello,world

.. csv-table:: should be Table 1.3
   :header-rows: 0

   hello,world

.. code-block:: python
   :caption: should be List 1.2

   print('hello world')

.. code-block:: python
   :caption: should be List 1.3

   print('hello world')

Foo A1
------

Foo B
=====

Foo B1
------

.. figure:: rimg.png

   should be Fig.1.4

.. csv-table:: should be Table 1.4
   :header-rows: 0

   hello,world

.. code-block:: python
   :caption: should be List 1.4

   print('hello world')
