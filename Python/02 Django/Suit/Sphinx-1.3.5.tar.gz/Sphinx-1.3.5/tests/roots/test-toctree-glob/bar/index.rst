Bar
===

.. toctree::
   :glob:

   *
   bar_4/index
