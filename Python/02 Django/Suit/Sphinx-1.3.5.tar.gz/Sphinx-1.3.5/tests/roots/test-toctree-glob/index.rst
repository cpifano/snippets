test-toctree-glob
=================

.. toctree::
   :glob:

   foo
   bar/index
   bar/*
   baz
   qux/index
